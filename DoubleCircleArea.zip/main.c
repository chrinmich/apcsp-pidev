#include <stdio.h>
#include <math.h>
#define PI 3.142
 
void main()
{
    float radius1, radius2, area1, area2;
 
    printf("Enter the radius of a first circle \n");
    scanf("%f", &radius1);
    area1 = PI * pow(radius1, 2);
    printf("Area of a first circle = %5.2f\n", area1);

    printf("Enter the radius of a second circle \n");
    scanf("%f", &radius2);
    area2 = PI * pow(radius2, 2);
    printf("Area of a second circle = %5.2f\n", area2);
}