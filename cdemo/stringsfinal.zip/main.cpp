#include <stdio.h>
#include <string.h>

int main() {
  char string1[]= "abcdefghijklmnopqrstuvwxyz";
  char string2[27];
  int i;
  char c = 'a';
  for (i = 0; i < 27; i++){

    string2[i] = c;
    c++;
  } //end of for loop
  string2[26] = '\0';
    printf("string1 = %s, string2 = %s\n", string1, string2);


    if (strcmp(string1, string2) == 0)
      printf("the strings are identical\n", );
    #include <stdio.h>
    #include <string.h>

    int main() {
      char string1[] = "abcdefghijklmnopqrstuvwxyz";
      char string2[27];
      int i;
    char c = 'a';
    for ( i = 0; i < 27; i++) {
    
    string2[i] = c;
    c++;
  } //end of for loop
  string2[26] = '\0';
    printf("string1 = %s, string2 = %s\n", string1, string2);


    if (strcmp(string1, string2) == 0)
      printf("the strings are identical\n");
    #include <stdio.h>
    #include <string.h>

    int main () {
      char string1[] = "abcdefghijklmnopqrstuvwxyz";
      char string2[27];
      int i;
    char c = 'a';
    for (i = 0; i < 27; i++){

      string2[i] = c;
      c++
    } //end of for loop
    string2[26] = '\0';
      printf("string1 = %s, string2 = %s\n", string1, string2);


      if(strcmp(string1, string2) == 0)
        printf("the strings areidential\n");
      else 
        printf("the strings are different\n");


        char C = 'a';
        for (i = 0; i < 27; i++){

          string2[i] = c - 59;
          c++;
        } //end of for loop
        string2[26] = '\0';
        printf("the updated string2 = %s\n", string2);




          else
            printf("the strings are different\n");

          char string3[54];
          strcpy(string3, string1);
          strcat(string3, string2);
          string3[53] ='\0';
          printf("string 3 = %s\n", string3);

          } //end of main